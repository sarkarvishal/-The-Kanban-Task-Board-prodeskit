import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import AddTaskForm from "./AddTaskForm.jsx";
import TaskCard from "./TaskCard.jsx";

function Column({ column, tasks, isFirst, onAddTask, onDeleteTask, onEditTask }) {
  // useDroppable makes the column itself a valid drop target - this is
  // what lets you drop a card into an EMPTY column (no other cards to
  // land "over"). id === column.id, which reorderTask in App.jsx checks
  // for to know "this was dropped on a column, not another task."
  const { setNodeRef, isOver } = useDroppable({ id: column.id });

  return (
    <section className={`column column--${column.id}`}>
      <header className="column-header">
        <h2 className="column-title">{column.title}</h2>
        <span className="column-count">{tasks.length}</span>
      </header>

      {/* New tasks always land in "To Do", so only that column gets the form */}
      {isFirst && <AddTaskForm onAddTask={onAddTask} />}

      <div ref={setNodeRef} className={`column-body ${isOver ? "column-body--over" : ""}`}>
        <SortableContext items={tasks.map((task) => task.id)} strategy={verticalListSortingStrategy}>
          {tasks.length === 0 ? (
            <p className="column-empty">Drop a task here.</p>
          ) : (
            tasks.map((task) => (
              <TaskCard key={task.id} task={task} onDeleteTask={onDeleteTask} onEditTask={onEditTask} />
            ))
          )}
        </SortableContext>
      </div>
    </section>
  );
}

export default Column;
