function SearchBar({ query, onQueryChange }) {
  return (
    <div className="search-bar">
      <input
        type="search"
        className="search-input"
        placeholder="Search tasks…"
        value={query}
        onChange={(event) => onQueryChange(event.target.value)}
        aria-label="Search tasks"
      />
    </div>
  );
}

export default SearchBar;
