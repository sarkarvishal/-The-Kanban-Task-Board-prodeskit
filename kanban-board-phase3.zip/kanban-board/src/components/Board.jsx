import { useState } from "react";
import {
  DndContext,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  closestCorners,
} from "@dnd-kit/core";
import { sortableKeyboardCoordinates } from "@dnd-kit/sortable";
import { COLUMNS, COLUMN_ORDER } from "../data/columns.js";
import Column from "./Column.jsx";
import SearchBar from "./SearchBar.jsx";

// Board is where drag-and-drop is wired up (DndContext + sensors) and
// where the live search query lives. Search is a pure display filter, not
// part of the persisted task data, so it makes sense as Board's own state
// rather than something lifted all the way up to App.
function Board({ tasks, onAddTask, onDeleteTask, onReorderTask, onEditTask }) {
  const [searchQuery, setSearchQuery] = useState("");

  // PointerSensor needs a small movement threshold so a plain click (e.g.
  // to open inline editing) isn't accidentally interpreted as a drag.
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const query = searchQuery.trim().toLowerCase();
  const visibleTasks = query
    ? tasks.filter((task) => task.text.toLowerCase().includes(query))
    : tasks;

  function handleDragEnd(event) {
    const { active, over } = event;
    if (!over) return;
    onReorderTask(active.id, over.id);
  }

  return (
    <div className="board-wrapper">
      <SearchBar query={searchQuery} onQueryChange={setSearchQuery} />

      <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
        <div className="board">
          {COLUMNS.map((column) => {
            const columnTasks = visibleTasks.filter((task) => task.status === column.id);
            const columnIndex = COLUMN_ORDER.indexOf(column.id);

            return (
              <Column
                key={column.id}
                column={column}
                tasks={columnTasks}
                isFirst={columnIndex === 0}
                onAddTask={onAddTask}
                onDeleteTask={onDeleteTask}
                onEditTask={onEditTask}
              />
            );
          })}
        </div>
      </DndContext>
    </div>
  );
}

export default Board;
