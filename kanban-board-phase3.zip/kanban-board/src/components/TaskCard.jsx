import { useState } from "react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { priorityClass } from "../data/priorities.js";

function TaskCard({ task, onDeleteTask, onEditTask }) {
  const [isEditing, setIsEditing] = useState(false);
  const [draftText, setDraftText] = useState(task.text);

  const { setNodeRef, attributes, listeners, transform, transition, isDragging } = useSortable({
    id: task.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  function startEditing() {
    setDraftText(task.text);
    setIsEditing(true);
  }

  function commitEdit() {
    const trimmed = draftText.trim();
    // Empty edits are discarded rather than saved, so a task can never be
    // blanked out by accident - it just reverts to its previous text.
    if (trimmed && trimmed !== task.text) {
      onEditTask(task.id, trimmed);
    }
    setIsEditing(false);
  }

  function cancelEdit() {
    setDraftText(task.text);
    setIsEditing(false);
  }

  function handleKeyDown(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      commitEdit();
    } else if (event.key === "Escape") {
      event.preventDefault();
      cancelEdit();
    }
  }

  return (
    <article ref={setNodeRef} style={style} className={`task-card ${priorityClass(task.priority)}`}>
      <div className="task-card-top">
        {/* Drag listeners are scoped to this handle only, so clicking the
            task text below still opens inline editing instead of starting
            a drag. */}
        <button
          type="button"
          className="task-drag-handle"
          aria-label="Drag to move task"
          {...attributes}
          {...listeners}
        >
          <span />
          <span />
          <span />
        </button>

        {isEditing ? (
          <input
            type="text"
            className="task-card-edit-input"
            value={draftText}
            onChange={(event) => setDraftText(event.target.value)}
            onBlur={commitEdit}
            onKeyDown={handleKeyDown}
            autoFocus
            aria-label="Edit task text"
          />
        ) : (
          <button type="button" className="task-card-text" onClick={startEditing}>
            {task.text}
          </button>
        )}
      </div>

      <div className="task-card-footer">
        <span className={`priority-tag priority-tag--${task.priority.toLowerCase()}`}>
          {task.priority}
        </span>

        <button
          type="button"
          className="task-btn task-btn--delete"
          onClick={() => onDeleteTask(task.id)}
          aria-label={`Delete task: ${task.text}`}
        >
          Delete
        </button>
      </div>
    </article>
  );
}

export default TaskCard;
