import { useState } from "react";
import { PRIORITIES, DEFAULT_PRIORITY } from "../data/priorities.js";

function AddTaskForm({ onAddTask }) {
  const [text, setText] = useState("");
  const [priority, setPriority] = useState(DEFAULT_PRIORITY);

  function handleSubmit(event) {
    event.preventDefault();
    if (!text.trim()) return;
    onAddTask(text, priority);
    setText("");
    setPriority(DEFAULT_PRIORITY);
  }

  return (
    <form className="add-task-form" onSubmit={handleSubmit}>
      <input
        type="text"
        className="add-task-input"
        placeholder="Add a task…"
        value={text}
        onChange={(event) => setText(event.target.value)}
        aria-label="New task text"
      />
      <select
        className="add-task-priority"
        value={priority}
        onChange={(event) => setPriority(event.target.value)}
        aria-label="Task priority"
      >
        {PRIORITIES.map((level) => (
          <option key={level} value={level}>
            {level}
          </option>
        ))}
      </select>
      <button type="submit" className="add-task-submit">
        Add
      </button>
    </form>
  );
}

export default AddTaskForm;
