import { useEffect, useState } from "react";
import Board from "./components/Board.jsx";
import { createId } from "./utils/createId.js";
import { DEFAULT_PRIORITY } from "./data/priorities.js";
import { COLUMN_ORDER } from "./data/columns.js";

// App owns the ENTIRE board's state as one flat array of task objects.
// Each task carries its own `status`, which is what determines which
// column it currently renders in (see Board.jsx). This is the classic
// "single source of truth" pattern - instead of three separate arrays
// (todo/inProgress/done) that you'd have to keep manually in sync,
// moving a task is just changing one field on one object.
//
// task shape:
// { id: string, text: string, status: "todo" | "inProgress" | "done", priority: "High" | "Medium" | "Low" }

const STORAGE_KEY = "kanban-board:tasks";

// Reads persisted tasks synchronously so the very first render already has
// them (avoids a flash of an empty board on refresh). Defensive against
// missing/corrupted localStorage data - a broken JSON blob should never
// crash the app, it should just fall back to an empty board.
function loadInitialTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Normalize older/partial records so a missing `priority` (e.g. from
    // a pre-Phase-2 save) never breaks the priority border logic.
    return parsed.map((task) => ({ priority: DEFAULT_PRIORITY, ...task }));
  } catch {
    return [];
  }
}

function App() {
  const [tasks, setTasks] = useState(loadInitialTasks);

  // --- Persistence ----------------------------------------------------
  // Any change to `tasks` (add/delete/move/edit) re-serializes the whole
  // array to localStorage, so a hard refresh restores exactly where the
  // board was left.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      // Storage can fail (private browsing, quota exceeded) - the board
      // still works in-memory for the session, it just won't persist.
    }
  }, [tasks]);

  // --- Add Task -----------------------------------------------------
  // New tasks always enter the board in the "To Do" column.
  function addTask(text, priority = DEFAULT_PRIORITY) {
    const trimmed = text.trim();
    if (!trimmed) return;

    const newTask = {
      id: createId(),
      text: trimmed,
      status: "todo",
      priority,
    };

    setTasks((prevTasks) => [...prevTasks, newTask]);
  }

  // --- Edit Task (inline editing) --------------------------------------
  // Commits new text for an existing task without touching its status
  // or priority.
  function editTask(taskId, newText) {
    const trimmed = newText.trim();
    if (!trimmed) return;

    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === taskId ? { ...task, text: trimmed } : task
      )
    );
  }

  // --- Delete Task ----------------------------------------------------
  // Universal delete: works the same regardless of which column the
  // card currently lives in, since we just filter by id.
  function deleteTask(taskId) {
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
  }

  // --- Move Task (drag-and-drop) ---------------------------------------
  // Powers dnd-kit's onDragEnd. `overId` is either another task's id
  // (dropped on top of a card - reorder/insert at that position) or a
  // column id (dropped on an empty column - append to the end of it).
  // Handles cross-column moves and same-column reordering with the same
  // logic, since both are just "remove active task, reinsert at the
  // right position, update its status." This replaces the Phase 1/2
  // button-driven moveTask entirely, per the Phase 3 brief.
  function reorderTask(activeId, overId) {
    if (!overId || activeId === overId) return;

    setTasks((prevTasks) => {
      const activeTask = prevTasks.find((task) => task.id === activeId);
      if (!activeTask) return prevTasks;

      const isOverColumn = COLUMN_ORDER.includes(overId);
      const overTask = isOverColumn ? null : prevTasks.find((task) => task.id === overId);
      const newStatus = isOverColumn ? overId : overTask?.status;
      if (!newStatus) return prevTasks;

      const withoutActive = prevTasks.filter((task) => task.id !== activeId);

      let insertIndex;
      if (isOverColumn) {
        // Dropped on empty column space: append after the last task
        // currently in that column.
        insertIndex = withoutActive.length;
        for (let i = withoutActive.length - 1; i >= 0; i -= 1) {
          if (withoutActive[i].status === newStatus) {
            insertIndex = i + 1;
            break;
          }
        }
      } else {
        insertIndex = withoutActive.findIndex((task) => task.id === overId);
        if (insertIndex === -1) insertIndex = withoutActive.length;
      }

      const updatedActiveTask = { ...activeTask, status: newStatus };
      const newTasks = [...withoutActive];
      newTasks.splice(insertIndex, 0, updatedActiveTask);
      return newTasks;
    });
  }

  return (
    <div className="app">
      <header className="app-header">
        <p className="app-eyebrow">Sprint 05 · Component Architecture</p>
        <h1 className="app-title">Kanban Task Board</h1>
      </header>

      <Board
        tasks={tasks}
        onAddTask={addTask}
        onDeleteTask={deleteTask}
        onReorderTask={reorderTask}
        onEditTask={editTask}
      />
    </div>
  );
}

export default App;
