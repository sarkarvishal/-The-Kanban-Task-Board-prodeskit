// Generates a reasonably unique id for a new task.
// crypto.randomUUID is supported in all modern evergreen browsers (Vite's target),
// with a timestamp+random fallback just in case.
export function createId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `task-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
