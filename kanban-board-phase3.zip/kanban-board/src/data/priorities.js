// Single source of truth for the priority system, same pattern as columns.js.
export const PRIORITIES = ["High", "Medium", "Low"];
export const DEFAULT_PRIORITY = "Medium";

// Maps a priority to the CSS modifier class TaskCard uses for its border color.
export function priorityClass(priority) {
  return `task-card--${priority.toLowerCase()}`;
}
