// Single source of truth for the board's structure.
// Adding a new column later (e.g. "Blocked") only means adding one entry here -
// Board.jsx, Column.jsx and the state logic in App.jsx don't need to change.
export const COLUMNS = [
  { id: "todo", title: "To Do" },
  { id: "inProgress", title: "In Progress" },
  { id: "done", title: "Done" },
];

// Defines the forward path a task takes across the board, so "Move" buttons
// always know what the "next" and "previous" column is for a given task.
export const COLUMN_ORDER = COLUMNS.map((col) => col.id);
