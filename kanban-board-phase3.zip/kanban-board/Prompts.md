# Prompts.md — Sprint 05: Kanban Task Board (Phase 1 + 2 + 3)

Transparency log of how this deliverable was built with AI assistance.

## Brief given

Full Sprint 05 brief across three phases. Phase 1: 3-column Kanban board
(To Do / In Progress / Done) in React, scaffolded via Vite (create-react-app
explicitly disallowed), with add/delete/move actions, all state-driven.
Phase 2: inline editing of task text, a High/Medium/Low priority system with
conditional border color, and localStorage persistence across hard
refreshes. Phase 3 (this update): deprecate the Move buttons in favor of
physical drag-and-drop via `dnd-kit`, plus a live search filter across all
columns.

## Approach taken

1. Scaffolded the project with `npm create vite@latest kanban-board --
   --template react`, confirming the prerequisite.
2. Modeled state as a single flat `tasks` array (`{ id, text, status }`)
   rather than three separate column arrays, so that "moving" a task is a
   single-field update instead of manual array surgery. This was a
   deliberate architecture decision beyond the letter of the brief, made to
   keep the state model simple and to set up Phase 3 (drag-and-drop)
   cleanly.
3. Split the UI into `App → Board → Column → TaskCard` to demonstrate
   explicit prop drilling, as the sprint's engineering objective specifies.
4. Applied an original visual system ("drafting desk": kraft-paper folder
   columns, tilted index-card tasks) instead of default dashboard styling.
5. Inline editing uses local component state in `TaskCard` (not lifted to
   `App`) since only one card is ever being edited at a time and no other
   component needs to know about editing-in-progress state.
6. localStorage read/write is wrapped in `try/catch` on both ends, and
   loaded records are normalized with a default `priority` in case older
   saved data predates the priority field.
7. Drag-and-drop uses `dnd-kit` (`core` + `sortable` + `utilities`), the
   library the brief explicitly suggested. Drag listeners are attached
   only to a dedicated grip handle on each card, not the whole card body,
   so that clicking a task's text still opens inline editing rather than
   starting a drag.
8. One `onDragEnd` handler (`reorderTask` in `App.jsx`) covers both
   cross-column moves and same-column reordering, since both are the same
   operation on the underlying flat array: remove the dragged task, then
   reinsert it at the right index with its `status` updated.
9. Search is a Board-level UI concern (not lifted into `App`/localStorage)
   since it's a transient display filter, not data that should persist
   across sessions.

## What to verify / review before submitting

- Confirm the single-array-with-status data model is acceptable to your
  reviewer versus three separate column arrays (both satisfy the brief;
  this repo took the former for the reasons above — flag this explicitly
  if your rubric expects three arrays).
- Run `npm install && npm run dev` locally and click through: add a task
  with each priority level, edit a task's text inline, drag it across
  columns and reorder it within a column, delete it, search to filter the
  board, then hard-refresh the page to confirm persistence.
- The Phase 1/2 button-driven move actions were intentionally removed per
  the Phase 3 brief ("deprecate the Move buttons") — flag if your reviewer
  wants both interaction methods available side by side.
